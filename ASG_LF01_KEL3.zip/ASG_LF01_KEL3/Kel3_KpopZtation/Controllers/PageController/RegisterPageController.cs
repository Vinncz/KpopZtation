﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Kel3_KpopZtation.Models;

namespace Kel3_KpopZtation.Controllers.PageController {
    public static class RegisterPageController {

        // public static (Customer AssociatedAccount, List<string> ErrorMsgs) 

    }
}